package com.example;

/**
 * Main Application Class
 * This is a simple class to represent our Java application.
 */
public class App {
    
    private String appName;
    
    public App() {
        this.appName = "Java Web Application";
    }
    
    public String getAppName() {
        return appName;
    }
    
    public void setAppName(String appName) {
        this.appName = appName;
    }
    
    @Override
    public String toString() {
        return "App [appName=" + appName + "]";
    }
    
    /**
     * Main method for standalone execution (not used in web app)
     */
    public static void main(String[] args) {
        App app = new App();
        System.out.println("Hello from " + app.getAppName());
    }
}
