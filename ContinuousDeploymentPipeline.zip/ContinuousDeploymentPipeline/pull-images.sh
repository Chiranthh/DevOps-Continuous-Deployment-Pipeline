#!/bin/bash
echo "Pulling Docker images for Jenkins and Tomcat..."
docker pull jenkins/jenkins:lts
docker pull tomcat:9.0
echo "Docker images downloaded successfully."