package com.example.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.example.App;

/**
 * Simple Servlet Controller to demonstrate the web application
 */
@WebServlet("/hello")
public class HelloController extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
    /**
     * Handle GET requests
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        // Set response content type
        response.setContentType("text/html");
        
        // Get current app details
        App app = new App();
        
        // Get deployment information
        String hostname = request.getServerName();
        int port = request.getServerPort();
        String deploymentInfo = hostname + ":" + port;
        
        // Write the response
        PrintWriter out = response.getWriter();
        out.println("<html>");
        out.println("<head>");
        out.println("<title>" + app.getAppName() + "</title>");
        out.println("<style>");
        out.println("body { font-family: Arial, sans-serif; margin: 40px; line-height: 1.6; }");
        out.println(".container { max-width: 800px; margin: 0 auto; padding: 20px; border: 1px solid #ddd; border-radius: 5px; }");
        out.println("h1 { color: #2c3e50; }");
        out.println("p { color: #34495e; }");
        out.println(".info { background-color: #f8f9fa; padding: 15px; border-radius: 5px; margin-top: 20px; }");
        out.println(".timestamp { color: #7f8c8d; font-size: 0.9em; margin-top: 30px; }");
        out.println("</style>");
        out.println("</head>");
        out.println("<body>");
        out.println("<div class='container'>");
        out.println("<h1>Welcome to " + app.getAppName() + "</h1>");
        out.println("<p>This is a sample Java web application deployed using Jenkins CI/CD and Tomcat.</p>");
        
        out.println("<div class='info'>");
        out.println("<h2>Deployment Information:</h2>");
        out.println("<p><strong>Server:</strong> " + deploymentInfo + "</p>");
        out.println("<p><strong>Servlet Path:</strong> " + request.getServletPath() + "</p>");
        out.println("<p><strong>Java Version:</strong> " + System.getProperty("java.version") + "</p>");
        out.println("</div>");
        
        out.println("<p class='timestamp'>Generated at: " + new Date() + "</p>");
        out.println("</div>");
        out.println("</body>");
        out.println("</html>");
    }
}
