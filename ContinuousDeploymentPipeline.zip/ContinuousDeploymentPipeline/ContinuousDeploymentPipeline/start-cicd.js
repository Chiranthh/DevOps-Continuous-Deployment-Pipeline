const express = require('express');
const path = require('path');
const { exec } = require('child_process');
const fs = require('fs');

// Initialize Express
const app = express();
const port = 5000;

// Configure middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

// Create necessary directories
if (!fs.existsSync('public')) {
  fs.mkdirSync('public');
}

// Create the HTML interface
const htmlContent = `
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>CI/CD Pipeline Simulator</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      margin: 0;
      padding: 20px;
      background-color: #f5f5f5;
      color: #333;
    }
    .container {
      max-width: 800px;
      margin: 0 auto;
      background-color: #fff;
      padding: 20px;
      border-radius: 5px;
      box-shadow: 0 2px 5px rgba(0,0,0,0.1);
    }
    h1 {
      color: #2c3e50;
      margin-top: 0;
    }
    .card {
      border: 1px solid #ddd;
      padding: 15px;
      margin-bottom: 20px;
      border-radius: 4px;
    }
    .card h2 {
      margin-top: 0;
      color: #3498db;
    }
    .status {
      display: inline-block;
      padding: 5px 10px;
      border-radius: 3px;
      font-weight: bold;
    }
    .running {
      background-color: #2ecc71;
      color: white;
    }
    .stopped {
      background-color: #e74c3c;
      color: white;
    }
    .unknown {
      background-color: #f39c12;
      color: white;
    }
    .success {
      background-color: #2ecc71;
      color: white;
    }
    .failure {
      background-color: #e74c3c;
      color: white;
    }
    .progress {
      background-color: #3498db;
      color: white;
    }
    button {
      background-color: #3498db;
      color: white;
      border: none;
      padding: 10px 15px;
      border-radius: 4px;
      cursor: pointer;
      font-size: 14px;
      margin-right: 10px;
    }
    button:hover {
      background-color: #2980b9;
    }
    button:disabled {
      background-color: #95a5a6;
      cursor: not-allowed;
    }
    .access-links {
      margin-top: 10px;
    }
    .access-links a {
      display: inline-block;
      margin-right: 10px;
      color: #3498db;
      text-decoration: none;
    }
    .access-links a:hover {
      text-decoration: underline;
    }
    #loading {
      display: none;
      margin-top: 20px;
      color: #7f8c8d;
      font-style: italic;
    }
    .info-box {
      background-color: #f8f9fa;
      border-left: 4px solid #3498db;
      padding: 10px 15px;
      margin: 20px 0;
    }
    .pipeline-stages {
      margin-top: 20px;
    }
    .stage {
      padding: 10px;
      margin-bottom: 5px;
      border-radius: 3px;
      background-color: #f8f9fa;
      border-left: 4px solid #3498db;
    }
    .stage.active {
      border-left: 4px solid #f39c12;
      background-color: #fef9e7;
    }
    .stage.success {
      border-left: 4px solid #2ecc71;
    }
    .stage.failed {
      border-left: 4px solid #e74c3c;
    }
    .log-container {
      margin-top: 20px;
      background-color: #2c3e50;
      color: #ecf0f1;
      padding: 15px;
      border-radius: 5px;
      font-family: monospace;
      font-size: 14px;
      max-height: 300px;
      overflow-y: auto;
    }
    .log-container pre {
      margin: 0;
      white-space: pre-wrap;
    }
  </style>
</head>
<body>
  <div class="container">
    <h1>CI/CD Pipeline Simulator</h1>
    <p>Simulates a Jenkins-Tomcat CI/CD pipeline for Java web applications</p>
    
    <div class="card">
      <h2>CI/CD Environment</h2>
      <div id="environment-status">
        <span class="status running">Ready</span>
      </div>
      <div class="info-box">
        <p><strong>Jenkins Simulation:</strong> Port 8080 (simulated)</p>
        <p><strong>Tomcat Simulation:</strong> Port 9090 (simulated)</p>
      </div>
    </div>
    
    <div class="card">
      <h2>Pipeline Controls</h2>
      <button id="start-pipeline">Start Pipeline</button>
      <button id="stop-pipeline" disabled>Stop Pipeline</button>
      <button id="reset-pipeline" disabled>Reset Pipeline</button>
      <div id="loading">Running pipeline, please wait...</div>
    </div>

    <div class="card">
      <h2>Pipeline Status</h2>
      <div id="pipeline-status">
        <span class="status unknown">Not Started</span>
      </div>
      
      <div class="pipeline-stages">
        <div id="stage-checkout" class="stage">
          <strong>1. Source Code Checkout</strong>
          <span class="status-indicator"></span>
        </div>
        <div id="stage-build" class="stage">
          <strong>2. Build & Compile</strong>
          <span class="status-indicator"></span>
        </div>
        <div id="stage-test" class="stage">
          <strong>3. Unit Tests</strong>
          <span class="status-indicator"></span>
        </div>
        <div id="stage-package" class="stage">
          <strong>4. Package WAR</strong>
          <span class="status-indicator"></span>
        </div>
        <div id="stage-deploy" class="stage">
          <strong>5. Deploy to Tomcat</strong>
          <span class="status-indicator"></span>
        </div>
        <div id="stage-verify" class="stage">
          <strong>6. Verify Deployment</strong>
          <span class="status-indicator"></span>
        </div>
      </div>
    </div>
    
    <div class="card">
      <h2>Pipeline Logs</h2>
      <div id="logs" class="log-container">
        <pre>CI/CD Pipeline ready. Click "Start Pipeline" to begin.</pre>
      </div>
    </div>
    
    <div class="info-box" style="margin-top: 30px;">
      <h3>About this Simulator:</h3>
      <p>This application simulates a CI/CD pipeline without requiring actual Docker containers. 
      It demonstrates the flow of a Jenkins and Tomcat pipeline for educational purposes.</p>
      <p>The simulation follows these stages:</p>
      <ol>
        <li>Source code checkout from a Git repository</li>
        <li>Building and compiling the Java application with Maven</li>
        <li>Running unit tests</li>
        <li>Packaging the application as a WAR file</li>
        <li>Deploying the WAR file to Tomcat</li>
        <li>Verifying the successful deployment</li>
      </ol>
    </div>
  </div>
  
  <script>
    document.addEventListener('DOMContentLoaded', function() {
      // Get DOM elements
      const startButton = document.getElementById('start-pipeline');
      const stopButton = document.getElementById('stop-pipeline');
      const resetButton = document.getElementById('reset-pipeline');
      const loadingIndicator = document.getElementById('loading');
      const pipelineStatus = document.getElementById('pipeline-status');
      const logsContainer = document.getElementById('logs');
      
      // Pipeline stages
      const stages = [
        'checkout',
        'build',
        'test',
        'package',
        'deploy',
        'verify'
      ];
      
      let pipelineRunning = false;
      let currentStage = null;
      let pipelineTimeout = null;
      
      // Add log entry
      function addLog(message, type = 'info') {
        const timestamp = new Date().toLocaleTimeString();
        const logEntry = document.createElement('div');
        logEntry.innerHTML = \`[\${timestamp}] \${message}\`;
        
        if (type === 'error') {
          logEntry.style.color = '#e74c3c';
        } else if (type === 'success') {
          logEntry.style.color = '#2ecc71';
        } else if (type === 'warning') {
          logEntry.style.color = '#f39c12';
        }
        
        logsContainer.appendChild(logEntry);
        logsContainer.scrollTop = logsContainer.scrollHeight;
      }
      
      // Update stage status
      function updateStage(stageName, status) {
        const stageElement = document.getElementById(\`stage-\${stageName}\`);
        
        // Remove existing classes
        stageElement.classList.remove('active', 'success', 'failed');
        
        // Add appropriate class
        if (status === 'active') {
          stageElement.classList.add('active');
        } else if (status === 'success') {
          stageElement.classList.add('success');
        } else if (status === 'failed') {
          stageElement.classList.add('failed');
        }
      }
      
      // Reset all stages
      function resetStages() {
        stages.forEach(stage => {
          const stageElement = document.getElementById(\`stage-\${stage}\`);
          stageElement.classList.remove('active', 'success', 'failed');
        });
      }
      
      // Run pipeline stage
      function runStage(stageIndex) {
        if (stageIndex >= stages.length) {
          // Pipeline completed
          addLog('Pipeline execution completed successfully!', 'success');
          pipelineStatus.innerHTML = '<span class="status success">Completed</span>';
          pipelineRunning = false;
          currentStage = null;
          stopButton.disabled = true;
          startButton.disabled = false;
          resetButton.disabled = false;
          loadingIndicator.style.display = 'none';
          return;
        }
        
        if (!pipelineRunning) {
          return; // Pipeline was stopped
        }
        
        const stageName = stages[stageIndex];
        currentStage = stageName;
        
        // Update UI
        updateStage(stageName, 'active');
        
        // Different log messages for each stage
        switch (stageName) {
          case 'checkout':
            addLog('Starting pipeline execution...');
            addLog('Checking out code from Git repository...');
            addLog('Using repository: https://github.com/yourusername/sample-java-app.git');
            addLog('Checking out branch: main');
            break;
            
          case 'build':
            addLog('Building and compiling the Java application...');
            addLog('Using Maven 3.8.1 and JDK 11');
            addLog('Running: mvn clean compile');
            addLog('[INFO] Building Java Web Application 1.0-SNAPSHOT');
            addLog('[INFO] Compiling Java source files');
            break;
            
          case 'test':
            addLog('Running unit tests...');
            addLog('Running: mvn test');
            addLog('[INFO] Executing test cases');
            addLog('[INFO] Tests run: 3, Failures: 0, Errors: 0, Skipped: 0');
            break;
            
          case 'package':
            addLog('Packaging the application as a WAR file...');
            addLog('Running: mvn package');
            addLog('[INFO] Building war: /workspace/sample-java-app/target/java-web-app.war');
            addLog('[INFO] WAR file created successfully');
            break;
            
          case 'deploy':
            addLog('Deploying to Tomcat server...');
            addLog('Using Tomcat deployment credentials');
            addLog('Connecting to Tomcat at: http://localhost:9090/manager/text');
            addLog('Undeploying existing application (if present)');
            addLog('Deploying WAR file to context path: /java-web-app');
            break;
            
          case 'verify':
            addLog('Verifying deployment...');
            addLog('Checking application availability');
            addLog('HTTP Status: 200 OK');
            addLog('Application successfully deployed and verified!', 'success');
            break;
        }
        
        // Simulate stage execution time (2-3 seconds per stage)
        const executionTime = 2000 + Math.random() * 1000;
        
        // Move to next stage after execution time
        pipelineTimeout = setTimeout(() => {
          // Mark current stage as success
          updateStage(stageName, 'success');
          
          // Move to next stage
          runStage(stageIndex + 1);
        }, executionTime);
      }
      
      // Start pipeline execution
      function startPipeline() {
        if (pipelineRunning) return;
        
        // Reset UI
        resetStages();
        logsContainer.innerHTML = '';
        
        // Update UI state
        pipelineRunning = true;
        loadingIndicator.style.display = 'block';
        startButton.disabled = true;
        stopButton.disabled = false;
        resetButton.disabled = true;
        pipelineStatus.innerHTML = '<span class="status progress">In Progress</span>';
        
        // Start execution with first stage
        addLog('Initializing CI/CD pipeline...', 'info');
        runStage(0);
      }
      
      // Stop pipeline execution
      function stopPipeline() {
        if (!pipelineRunning) return;
        
        // Clear timeout if any
        if (pipelineTimeout) {
          clearTimeout(pipelineTimeout);
          pipelineTimeout = null;
        }
        
        // Update UI state
        pipelineRunning = false;
        loadingIndicator.style.display = 'none';
        startButton.disabled = false;
        stopButton.disabled = true;
        resetButton.disabled = false;
        pipelineStatus.innerHTML = '<span class="status stopped">Stopped</span>';
        
        // Update logs
        if (currentStage) {
          updateStage(currentStage, 'failed');
          addLog(\`Pipeline execution stopped during '\${currentStage}' stage\`, 'warning');
        }
      }
      
      // Reset pipeline
      function resetPipeline() {
        // Reset UI
        resetStages();
        logsContainer.innerHTML = '<pre>CI/CD Pipeline ready. Click "Start Pipeline" to begin.</pre>';
        loadingIndicator.style.display = 'none';
        startButton.disabled = false;
        stopButton.disabled = true;
        resetButton.disabled = true;
        pipelineStatus.innerHTML = '<span class="status unknown">Not Started</span>';
        
        // Reset state
        pipelineRunning = false;
        currentStage = null;
      }
      
      // Event listeners
      startButton.addEventListener('click', startPipeline);
      stopButton.addEventListener('click', stopPipeline);
      resetButton.addEventListener('click', resetPipeline);
    });
  </script>
</body>
</html>
`;

// Write HTML to file
fs.writeFileSync(path.join(__dirname, 'public', 'index.html'), htmlContent);

// Serve the index.html file
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Start the server
app.listen(port, '0.0.0.0', () => {
  console.log(`CI/CD Pipeline Simulator running at http://localhost:${port}`);
});