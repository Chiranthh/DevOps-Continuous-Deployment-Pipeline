#!/bin/bash

# Display start message
echo "Starting CI/CD Pipeline setup using Docker..."

# Create a directory for our setup files
mkdir -p ci-cd-docker
cd ci-cd-docker

# Create a simple Node.js application to manage our containers
cat > server.js << 'EOF'
const express = require('express');
const Docker = require('dockerode');
const path = require('path');
const fs = require('fs');
const { exec } = require('child_process');

// Initialize Express and Docker
const app = express();
const docker = new Docker();
const port = 5000;

// Configure middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

// Serve static files
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// API endpoint to check container status
app.get('/api/status', async (req, res) => {
  try {
    const containers = await docker.listContainers({ all: true });
    const jenkinsContainer = containers.find(container => 
      container.Names.some(name => name.includes('jenkins')));
    const tomcatContainer = containers.find(container => 
      container.Names.some(name => name.includes('tomcat')));
    
    res.json({
      jenkins: jenkinsContainer ? 
        { id: jenkinsContainer.Id, state: jenkinsContainer.State, status: jenkinsContainer.Status } : 
        { status: 'not found' },
      tomcat: tomcatContainer ? 
        { id: tomcatContainer.Id, state: tomcatContainer.State, status: tomcatContainer.Status } : 
        { status: 'not found' }
    });
  } catch (error) {
    console.error('Error checking container status:', error);
    res.status(500).json({ error: error.message });
  }
});

// API endpoint to start containers
app.post('/api/start', async (req, res) => {
  try {
    // Start Jenkins container
    console.log('Starting Jenkins container...');
    await startJenkinsContainer();
    
    // Start Tomcat container
    console.log('Starting Tomcat container...');
    await startTomcatContainer();
    
    res.json({ message: 'Containers starting. This may take a few minutes.' });
  } catch (error) {
    console.error('Error starting containers:', error);
    res.status(500).json({ error: error.message });
  }
});

// Function to start Jenkins container
async function startJenkinsContainer() {
  try {
    // Check if container exists
    const containers = await docker.listContainers({ all: true });
    const jenkinsContainer = containers.find(container => 
      container.Names.some(name => name.includes('jenkins-cicd')));
    
    if (jenkinsContainer) {
      // If container exists but is not running, start it
      if (jenkinsContainer.State !== 'running') {
        const container = docker.getContainer(jenkinsContainer.Id);
        await container.start();
        console.log('Existing Jenkins container started');
      } else {
        console.log('Jenkins container is already running');
      }
      return;
    }
    
    // Create and start the container
    await docker.createContainer({
      Image: 'jenkins/jenkins:lts',
      name: 'jenkins-cicd',
      ExposedPorts: {
        '8080/tcp': {}
      },
      HostConfig: {
        PortBindings: {
          '8080/tcp': [{ HostPort: '8080' }]
        },
        Binds: [
          `${process.cwd()}/jenkins_home:/var/jenkins_home`
        ]
      }
    }).then(container => {
      return container.start();
    });
    
    console.log('New Jenkins container created and started');
  } catch (error) {
    console.error('Error with Jenkins container:', error);
    throw error;
  }
}

// Function to start Tomcat container
async function startTomcatContainer() {
  try {
    // Check if container exists
    const containers = await docker.listContainers({ all: true });
    const tomcatContainer = containers.find(container => 
      container.Names.some(name => name.includes('tomcat-cicd')));
    
    if (tomcatContainer) {
      // If container exists but is not running, start it
      if (tomcatContainer.State !== 'running') {
        const container = docker.getContainer(tomcatContainer.Id);
        await container.start();
        console.log('Existing Tomcat container started');
      } else {
        console.log('Tomcat container is already running');
      }
      return;
    }
    
    // Create tomcat users configuration
    if (!fs.existsSync('tomcat-conf')) {
      fs.mkdirSync('tomcat-conf');
    }
    
    fs.writeFileSync('tomcat-conf/tomcat-users.xml', `
<?xml version="1.0" encoding="UTF-8"?>
<tomcat-users xmlns="http://tomcat.apache.org/xml"
              xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
              xsi:schemaLocation="http://tomcat.apache.org/xml tomcat-users.xsd"
              version="1.0">
  <role rolename="manager-gui"/>
  <role rolename="manager-script"/>
  <role rolename="manager-jmx"/>
  <role rolename="manager-status"/>
  <role rolename="admin-gui"/>
  <role rolename="admin-script"/>
  
  <user username="tomcat" password="tomcat" roles="manager-gui"/>
  <user username="admin" password="admin" roles="manager-gui,admin-gui"/>
  <user username="deployer" password="deployer" roles="manager-script"/>
</tomcat-users>
    `);
    
    // Disable access restriction for Manager app
    fs.writeFileSync('tomcat-conf/context.xml', `
<?xml version="1.0" encoding="UTF-8"?>
<Context antiResourceLocking="false" privileged="true" >
  <!-- Comment out the valve to allow remote access to Manager app -->
  <!--
  <Valve className="org.apache.catalina.valves.RemoteAddrValve"
         allow="127\\.\\d+\\.\\d+\\.\\d+|::1|0:0:0:0:0:0:0:1" />
  -->
  <Manager sessionAttributeValueClassNameFilter="java\\.lang\\.(?:Boolean|Integer|Long|Number|String)|org\\.apache\\.catalina\\.filters\\.CsrfPreventionFilter\\$LruCache(?:\\$1)?|java\\.util\\.(?:Linked)?HashMap"/>
</Context>
    `);
    
    // Create and start the container
    await docker.createContainer({
      Image: 'tomcat:9.0',
      name: 'tomcat-cicd',
      ExposedPorts: {
        '8080/tcp': {}
      },
      HostConfig: {
        PortBindings: {
          '8080/tcp': [{ HostPort: '9090' }]
        },
        Binds: [
          `${process.cwd()}/tomcat-conf/tomcat-users.xml:/usr/local/tomcat/conf/tomcat-users.xml`,
          `${process.cwd()}/tomcat-conf/context.xml:/usr/local/tomcat/webapps/manager/META-INF/context.xml`,
          `${process.cwd()}/tomcat-conf/context.xml:/usr/local/tomcat/webapps/host-manager/META-INF/context.xml`
        ]
      }
    }).then(container => {
      return container.start();
    });
    
    console.log('New Tomcat container created and started');
  } catch (error) {
    console.error('Error with Tomcat container:', error);
    throw error;
  }
}

// Start the server
app.listen(port, '0.0.0.0', () => {
  console.log(`CI/CD Pipeline Manager running at http://localhost:${port}`);
  console.log('Use the web interface to manage Jenkins and Tomcat containers');
});
EOF

# Create HTML interface
mkdir -p public
cat > public/index.html << 'EOF'
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>CI/CD Pipeline Manager</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      margin: 0;
      padding: 20px;
      background-color: #f5f5f5;
      color: #333;
    }
    .container {
      max-width: 800px;
      margin: 0 auto;
      background-color: #fff;
      padding: 20px;
      border-radius: 5px;
      box-shadow: 0 2px 5px rgba(0,0,0,0.1);
    }
    h1 {
      color: #2c3e50;
      margin-top: 0;
    }
    .card {
      border: 1px solid #ddd;
      padding: 15px;
      margin-bottom: 20px;
      border-radius: 4px;
    }
    .card h2 {
      margin-top: 0;
      color: #3498db;
    }
    .status {
      display: inline-block;
      padding: 5px 10px;
      border-radius: 3px;
      font-weight: bold;
    }
    .running {
      background-color: #2ecc71;
      color: white;
    }
    .stopped {
      background-color: #e74c3c;
      color: white;
    }
    .unknown {
      background-color: #f39c12;
      color: white;
    }
    button {
      background-color: #3498db;
      color: white;
      border: none;
      padding: 10px 15px;
      border-radius: 4px;
      cursor: pointer;
      font-size: 14px;
    }
    button:hover {
      background-color: #2980b9;
    }
    .access-links {
      margin-top: 10px;
    }
    .access-links a {
      display: inline-block;
      margin-right: 10px;
      color: #3498db;
      text-decoration: none;
    }
    .access-links a:hover {
      text-decoration: underline;
    }
    #loading {
      display: none;
      margin-top: 20px;
      color: #7f8c8d;
      font-style: italic;
    }
    .info-box {
      background-color: #f8f9fa;
      border-left: 4px solid #3498db;
      padding: 10px 15px;
      margin: 20px 0;
    }
  </style>
</head>
<body>
  <div class="container">
    <h1>CI/CD Pipeline Manager</h1>
    <p>Manage your Jenkins and Tomcat containers for the CI/CD pipeline</p>
    
    <div class="card">
      <h2>Jenkins</h2>
      <div id="jenkins-status">
        <span class="status unknown">Unknown</span>
      </div>
      <div class="access-links">
        <a href="http://localhost:8080" target="_blank">Access Jenkins UI (Port 8080)</a>
      </div>
      <div class="info-box">
        <p><strong>Initial Admin Password:</strong> Check container logs for initial setup</p>
      </div>
    </div>
    
    <div class="card">
      <h2>Tomcat</h2>
      <div id="tomcat-status">
        <span class="status unknown">Unknown</span>
      </div>
      <div class="access-links">
        <a href="http://localhost:9090" target="_blank">Access Tomcat (Port 9090)</a>
        <a href="http://localhost:9090/manager/html" target="_blank">Tomcat Manager</a>
      </div>
      <div class="info-box">
        <p><strong>Manager Credentials:</strong> Username: tomcat | Password: tomcat</p>
        <p><strong>Jenkins Deployment Credentials:</strong> Username: deployer | Password: deployer</p>
      </div>
    </div>
    
    <button id="start-button">Start CI/CD Containers</button>
    <div id="loading">Starting containers, please wait...</div>
    
    <div class="info-box" style="margin-top: 30px;">
      <h3>Next Steps:</h3>
      <ol>
        <li>Start the containers using the button above</li>
        <li>Access Jenkins UI and complete the initial setup</li>
        <li>Configure Jenkins with the Java and Maven tools</li>
        <li>Create a Pipeline job using the Jenkinsfile from your project</li>
        <li>Run the pipeline to build and deploy the Java application to Tomcat</li>
      </ol>
    </div>
  </div>
  
  <script>
    document.addEventListener('DOMContentLoaded', function() {
      // Check status on page load
      checkStatus();
      
      // Setup periodic status checks
      setInterval(checkStatus, 5000);
      
      // Handle start button click
      document.getElementById('start-button').addEventListener('click', function() {
        startContainers();
      });
      
      // Function to check container status
      function checkStatus() {
        fetch('/api/status')
          .then(response => response.json())
          .then(data => {
            updateContainerStatus('jenkins', data.jenkins);
            updateContainerStatus('tomcat', data.tomcat);
          })
          .catch(error => {
            console.error('Error checking status:', error);
          });
      }
      
      // Function to update status display
      function updateContainerStatus(container, status) {
        const statusElement = document.getElementById(`${container}-status`);
        let statusText = 'Unknown';
        let statusClass = 'unknown';
        
        if (status.state === 'running') {
          statusText = 'Running';
          statusClass = 'running';
        } else if (status.status === 'not found') {
          statusText = 'Not Created';
          statusClass = 'stopped';
        } else {
          statusText = 'Stopped';
          statusClass = 'stopped';
        }
        
        statusElement.innerHTML = `<span class="status ${statusClass}">${statusText}</span>`;
        if (status.status && status.status !== 'not found') {
          statusElement.innerHTML += `<p>${status.status}</p>`;
        }
      }
      
      // Function to start containers
      function startContainers() {
        document.getElementById('loading').style.display = 'block';
        document.getElementById('start-button').disabled = true;
        
        fetch('/api/start', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          }
        })
        .then(response => response.json())
        .then(data => {
          console.log(data.message);
          // Keep loading message visible
          setTimeout(() => {
            document.getElementById('start-button').disabled = false;
            checkStatus();
          }, 3000);
        })
        .catch(error => {
          console.error('Error starting containers:', error);
          document.getElementById('loading').style.display = 'none';
          document.getElementById('start-button').disabled = false;
        });
      }
    });
  </script>
</body>
</html>
EOF

# Create package.json for our application
cat > package.json << 'EOF'
{
  "name": "cicd-pipeline-manager",
  "version": "1.0.0",
  "description": "A web interface to manage CI/CD pipeline containers",
  "main": "server.js",
  "scripts": {
    "start": "node server.js"
  },
  "dependencies": {
    "express": "^4.18.2",
    "dockerode": "^3.3.5"
  }
}
EOF

# Return to the original directory
cd ..

# Create a script to pull necessary Docker images
cat > pull-images.sh << 'EOF'
#!/bin/bash
echo "Pulling Docker images for Jenkins and Tomcat..."
docker pull jenkins/jenkins:lts
docker pull tomcat:9.0
echo "Docker images downloaded successfully."
EOF

chmod +x pull-images.sh

echo "Setup complete! Run the application with 'node ci-cd-docker/server.js'"
echo "Access the CI/CD Pipeline Manager at http://localhost:5000"
echo "You can pull the Docker images first by running './pull-images.sh'"